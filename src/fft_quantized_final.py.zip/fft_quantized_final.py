import numpy as np
import math
import csv
import matplotlib.pyplot as plt

###############################################################################
# Fixed-point format helpers
###############################################################################

def fxp_specs(int_bits, frac_bits, total_bits=16):
    assert int_bits + frac_bits == total_bits
    return {
        "int_bits": int_bits,
        "frac_bits": frac_bits,
        "total_bits": total_bits,
        "min_code": -(2**(total_bits-1)),
        "max_code":  (2**(total_bits-1) - 1),
        "scale":    2**frac_bits,
    }

def float_to_fxp(val, fmt):
    scale = fmt["scale"]
    lo = fmt["min_code"]
    hi = fmt["max_code"]

    def q_scalar(z):
        if np.iscomplexobj(z):
            #r = np.round(z.real * scale)
            r = np.trunc(z.real*scale)
            #if r == 1098:
             #   print("z=,z.scal=, r=",z.real,z.real*scale,r)
            #i = np.round(z.imag * scale)
            i = np.trunc(z.imag*scale)
            r = np.clip(r, lo, hi)
            i = np.clip(i, lo, hi)
            return r.astype(np.int32) + 1j * i.astype(np.int32)
        else:
            #zz = np.round(z * scale)
            zz = np.trunc(z*scale)
            if zz == 1098:
                print("z=, zz=",z*scale,zz)
            zz = np.clip(zz, lo, hi)
            return zz.astype(np.int32)

    if isinstance(val, np.ndarray):
        out = np.zeros(val.shape, dtype=complex if np.iscomplexobj(val) else np.int32)
        it = np.nditer(val, flags=['multi_index','refs_ok'], op_flags=['readonly'])
        while not it.finished:
            out[it.multi_index] = q_scalar(it[0].item())
            it.iternext()
        return out
    else:
        return q_scalar(val)

def fxp_to_float(val, fmt):
    scale = fmt["scale"]
    if np.iscomplexobj(val):
        return (val.real / scale) + 1j * (val.imag / scale)
    else:
        return val / scale

def fxp_add(a, b, fmt):
    lo = fmt["min_code"]
    hi = fmt["max_code"]

    if np.iscomplexobj(a) or np.iscomplexobj(b):
        ar = a.real if np.iscomplexobj(a) else a
        ai = a.imag if np.iscomplexobj(a) else 0
        br = b.real if np.iscomplexobj(b) else b
        bi = b.imag if np.iscomplexobj(b) else 0

        rr = ar.astype(np.int64) + br.astype(np.int64)
        ii = ai.astype(np.int64) + bi.astype(np.int64)
        rr = np.clip(rr, lo, hi).astype(np.int32)
        ii = np.clip(ii, lo, hi).astype(np.int32)
        return rr + 1j * ii
    else:
        c = a.astype(np.int64) + b.astype(np.int64)
        c = np.clip(c, lo, hi).astype(np.int32)
        return c

def fxp_sub(a, b, fmt):
    lo = fmt["min_code"]
    hi = fmt["max_code"]

    if np.iscomplexobj(a) or np.iscomplexobj(b):
        ar = a.real if np.iscomplexobj(a) else a
        ai = a.imag if np.iscomplexobj(a) else 0
        br = b.real if np.iscomplexobj(b) else b
        bi = b.imag if np.iscomplexobj(b) else 0

        rr = ar.astype(np.int64) - br.astype(np.int64)
        ii = ai.astype(np.int64) - bi.astype(np.int64)
        rr = np.clip(rr, lo, hi).astype(np.int32)
        ii = np.clip(ii, lo, hi).astype(np.int32)
        return rr + 1j * ii
    else:
        c = a.astype(np.int64) - b.astype(np.int64)
        c = np.clip(c, lo, hi).astype(np.int32)
        return c

def fxp_mul(a, b, fmt_a, fmt_b, fmt_out):
    fa = fmt_a["frac_bits"]
    fb = fmt_b["frac_bits"]
    fo = fmt_out["frac_bits"]
    shift = fa + fb - fo

    lo = fmt_out["min_code"]
    hi = fmt_out["max_code"]

    def round_shift(v):
        if shift > 0:
            bias = (1 << (shift-1))
            v_pos = v >= 0
            v_rounded = np.where(v_pos, v + bias, v - bias)
            v_s = v_rounded >> shift
        elif shift < 0:
            v_s = v << (-shift)
        else:
            v_s = v
        return v_s

    if np.iscomplexobj(a) or np.iscomplexobj(b):
        ar = a.real if np.iscomplexobj(a) else a
        ai = a.imag if np.iscomplexobj(a) else 0
        br = b.real if np.iscomplexobj(b) else b
        bi = b.imag if np.iscomplexobj(b) else 0

        pr = ar.astype(np.int64)*br.astype(np.int64) - ai.astype(np.int64)*bi.astype(np.int64)
        pi = ar.astype(np.int64)*bi.astype(np.int64) + ai.astype(np.int64)*br.astype(np.int64)

        pr_s = round_shift(pr)
        pi_s = round_shift(pi)

        pr_s = np.clip(pr_s, lo, hi).astype(np.int32)
        pi_s = np.clip(pi_s, lo, hi).astype(np.int32)

        return pr_s + 1j * pi_s
    else:
        prod = a.astype(np.int64)*b.astype(np.int64)
        prod_s = round_shift(prod)
        prod_s = np.clip(prod_s, lo, hi).astype(np.int32)
        return prod_s

def twiddle_quantized(k, block):
    angle = -2j * np.pi * k / block
    W = np.exp(angle)
    fmt_tw = fxp_specs(1,11,12)  # Q1.15
    return float_to_fxp(W, fmt_tw), fmt_tw

###############################################################################
# CSV writer helper
###############################################################################
def write_stage_csv(filename, X):
    with open(filename, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["real", "imag"])
        for x in X:
            w.writerow([int(np.real(x)), int(np.imag(x))])

def write_inp_csv(filename, X):
    with open(filename, "w", newline="") as f:
        w = csv.writer(f)
        # optional header
        w.writerow(["sample"])
        for x in X:
            w.writerow([x])

###############################################################################
# Fixed-point DIF FFT core (your version)
###############################################################################

def dif_fft_radix2_fixedpoint(x_adc,base_filename="stage"):
    N = x_adc.shape[0]
    assert N == 256
    nstages = int(math.log2(N))
    assert nstages == 8

    stage_formats = [
         fxp_specs(2,16,18),
         fxp_specs(3,15,18),
         fxp_specs(4,14,18),
         fxp_specs(5,13,18),
         fxp_specs(6,12,18),
         fxp_specs(7,11,18),
         fxp_specs(8,10,18),
         fxp_specs(9,9,18),
    ]

    fmt_stage0 = fxp_specs(1,11,12)
    X = float_to_fxp(x_adc.astype(np.complex128), fmt_stage0)
    write_stage_csv(f"{base_filename}input_18b.csv", X)

    step = N // 2
    stage_idx = 0
    while step >= 1:
        fmt_stage = stage_formats[stage_idx]
        half_step = step
        block = 2 * step

        for start in range(0, N, block):
            for k in range(half_step):
                Wq, fmt_tw = twiddle_quantized(k, block)

                i_top = start + k
                i_bot = i_top + half_step

                top = X[i_top]
                bot = X[i_bot]

                add_val = fxp_add(top, bot, fmt_stage)
                sub_val = fxp_sub(top, bot, fmt_stage)
                bot_new = fxp_mul(sub_val, Wq, fmt_stage, fmt_tw, fmt_stage)

                X[i_top] = add_val
                X[i_bot] = bot_new

        
        step //= 2
        stage_idx += 1

        if stage_idx < nstages:
            fmt_next = stage_formats[stage_idx]
            X_float = fxp_to_float(X, fmt_stage)
            X = float_to_fxp(X_float, fmt_next)
            write_stage_csv(f"{base_filename}{stage_idx}_output_18b.csv", X)

    # bit-reverse
    def bit_reverse_indices(n):
        bits = int(math.log2(n))
        out = np.zeros(n, dtype=int)
        for i in range(n):
            b = f"{i:0{bits}b}"
            out[i] = int(b[::-1], 2)
        return out


    rev = bit_reverse_indices(N)
    X_br = X[rev]
    write_stage_csv("final_fft_output.csv", X_br)

    return X_br
###############################################################################
# ADC quantization model: 12-bit Q1.11
###############################################################################

def adc_quantize_q1_11(x):
    scale = 2048.0
    code = np.round(x * scale)
    code = np.clip(code, -2048, 2047)
    return code / scale

###############################################################################
# SNR calculation (tone bin vs rest)
###############################################################################

def compute_snr_from_fft_bins(X_bins, fs_hz):
    N2 = len(X_bins)
    N  = (N2 - 1) * 2

    mag = np.abs(X_bins)
    #bin_rms = (mag * (2.0 / N)) / np.sqrt(2.0)
    bin_rms = mag
    bin_power = bin_rms**2

    fund_bin = np.argmax(bin_power[1:]) + 1

    p_sig = bin_power[fund_bin]

    exclude = [0, fund_bin]
    noise_bins = [i for i in range(len(bin_power)) if i not in exclude]
    p_noise = np.sum(bin_power[noise_bins])

    snr_db = 10*np.log10(p_sig / (p_noise + 1e-30))
    return snr_db, fund_bin, p_sig, p_noise

def snr_numpy_path(x_q, Fs):
    N = len(x_q)
    X_np = np.fft.rfft(x_q, n=N)
    return compute_snr_from_fft_bins(X_np, Fs)

def snr_fixedpoint_path(x_q, Fs):
    X_full = dif_fft_radix2_fixedpoint(x_q)
    X_pos = X_full[: len(x_q)//2 + 1]
    return compute_snr_from_fft_bins(X_pos, Fs)

###############################################################################
# Main test + MSE
###############################################################################

if __name__ == "__main__":
    Fs = 256
    N  = 256
    tone_bin = 11
    fin = tone_bin * Fs / N

    amp = 0.9
    n = np.arange(N)
    x_analog = amp * np.sin(2*np.pi*fin*n/Fs)

    x_q = adc_quantize_q1_11(x_analog)
    write_inp_csv("sine.csv", x_q)
    # NumPy reference SNR (1-sided)
    snr_np, fund_np, p_sig_np, p_noise_np = snr_numpy_path(x_q, Fs)

    # Fixed-point SNR (1-sided)
    snr_fx, fund_fx, p_sig_fx, p_noise_fx = snr_fixedpoint_path(x_q, Fs)

    # === MSE PART ===========================================================
    # full NumPy FFT (complex, 256 bins)
    X_np_full = np.fft.fft(x_q, n=N)
    # full fixed-point FFT (complex, 256 bins, already bit-reversed -> natural)
    X_fx_full = dif_fft_radix2_fixedpoint(x_q)

    # MSE over all 256 bins
    mse_all = np.mean(np.abs(X_fx_full - X_np_full)**2)

    # MSE over 0..N/2 (to match SNR style)
    mse_pos = np.mean(np.abs(X_fx_full[:N//2+1] - X_np_full[:N//2+1])**2)
    # ========================================================================

    print("===== Results =====")
    print("NumPy FFT:")
    print(f"  fund bin      = {fund_np}")
    print(f"  signal power  = {p_sig_np:.3e}")
    print(f"  noise power   = {p_noise_np:.3e}")
    print(f"  SNR (dB)      = {snr_np:.2f} dB\n")

    print("Fixed-point FFT (your staged widths):")
    print(f"  fund bin      = {fund_fx}")
    print(f"  signal power  = {p_sig_fx:.3e}")
    print(f"  noise power   = {p_noise_fx:.3e}")
    print(f"  SNR (dB)      = {snr_fx:.2f} dB\n")

    print("MSE vs NumPy:")
    print(f"  MSE (all 256 bins): {mse_all:.6e}")
    print(f"  MSE (0..N/2 bins):  {mse_pos:.6e}")



    #############################################
    ############## Spectral Mapping #############
    #############################################

    # -------------------------------------------------
    # Signal generation
    # -------------------------------------------------
    n_long = np.arange(N * 16)
    L = len(n_long)
    half = L // 2
    
    fin2 = min(3 * fin, 0.45 * Fs)
    
    x_analog_new = np.zeros(L, dtype=np.float32)
    x_analog_new[:half] = amp * np.sin(2 * np.pi * fin  * n_long[:half] / Fs)
    x_analog_new[half:] = 0.6 * amp * np.sin(2 * np.pi * fin2 * n_long[half:] / Fs)
    
    x_long = adc_quantize_q1_11(x_analog_new)
    
    assert len(x_long) >= N, "Signal must be at least one FFT frame long"
    
    # -------------------------------------------------
    # STFT settings
    # -------------------------------------------------
    fft_len = 256                 # explicit 256-point FFT
    hop = fft_len // 4            # 75% overlap
    n_freqs = fft_len // 2 + 1
    n_frames = 1 + (len(x_long) - fft_len) // hop
    
    win = np.hanning(fft_len).astype(np.float32)
    
    spec_fixed = np.zeros((n_frames, n_freqs), dtype=np.float64)
    spec_npfft = np.zeros((n_frames, n_freqs), dtype=np.float64)
    
    # -------------------------------------------------
    # Frame processing
    # -------------------------------------------------
    for m in range(n_frames):
        start = m * hop
    
        frame_fp = x_long[start:start + fft_len].astype(np.float32)
        frame_np = x_analog_new[start:start + fft_len].astype(np.float32)
    
        frame_fp_win = frame_fp * win
        frame_np_win = frame_np * win
    
        # ---- Fixed-point FFT path ----
        X_fixed_full = dif_fft_radix2_fixedpoint(frame_fp_win)
        X_fixed_pos = X_fixed_full[:n_freqs]
        spec_fixed[m, :] = np.abs(X_fixed_pos) / (np.sum(win) + 1e-12)
    
        # ---- NumPy FFT path (256-point, FP32 input) ----
        X_np = np.fft.rfft(frame_np_win.astype(np.float32), n=fft_len)
        spec_npfft[m, :] = np.abs(X_np) / (np.sum(win) + 1e-12)
    
    # -------------------------------------------------
    # dB conversion
    # -------------------------------------------------
    eps = 1e-12
    spec_fixed_db = 20 * np.log10(spec_fixed + eps)
    spec_npfft_db = 20 * np.log10(spec_npfft + eps)
    
    # Normalizing each plot to its own peak
    spec_fixed_db -= np.max(spec_fixed_db)
    spec_npfft_db -= np.max(spec_npfft_db)
    
    freq_axis = (Fs / fft_len) * np.arange(n_freqs)
    time_axis = (hop / Fs) * np.arange(n_frames)
    
    # -------------------------------------------------
    # Plot both spectrograms
    # -------------------------------------------------
    fig, ax = plt.subplots(1, 2, figsize=(14, 5), sharex=True, sharey=True)
    
    pcm0 = ax[1].pcolormesh(time_axis, freq_axis, spec_fixed_db.T,
                            shading='auto', cmap='viridis')
    ax[1].set_title("Fixed-Point FFT Spectrogram")
    ax[1].set_xlabel("Time (s)")
    ax[1].set_ylabel("Frequency (Hz)")
    ax[1].set_ylim(0, Fs / 2)
    fig.colorbar(pcm0, ax=ax[1], label="Magnitude (dB, normalized)")
    
    pcm1 = ax[0].pcolormesh(time_axis, freq_axis, spec_npfft_db.T,
                            shading='auto', cmap='viridis')
    ax[0].set_title("NumPy FFT Spectrogram (256-pt, FP32)")
    ax[0].set_xlabel("Time (s)")
    ax[0].set_ylim(0, Fs / 2)
    fig.colorbar(pcm1, ax=ax[0], label="Magnitude (dB, normalized)")
    
    plt.tight_layout()
    plt.show()